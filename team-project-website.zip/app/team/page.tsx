import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Github, Linkedin, Mail, Twitter } from "lucide-react"

export default function TeamPage() {
  const teamMembers = [
    {
      name: "Meshal abdullah alamri",
      role: "UI/UX",
      bio: "static student at king saud university ",
      image: "/placeholder.svg?height=400&width=400",
      social: {
        twitter: "#",
        linkedin: "#",
        github: "#",
        email: "445101618@student.ksu.edu.sa",
      },
    },
    {
      name: "Abdullah Al-Othman",
      role: "Lead Developer",
      bio: "Abdullah is an expert in full-stack development with a focus on scalable architecture and performance optimization.",
      image: "/placeholder.svg?height=400&width=400",
      social: {
        twitter: "#",
        linkedin: "#",
        github: "#",
        email: "abdullah@ksu.edu.sa",
      },
    },
    {
      name: "Faisal Al-Mubarak",
      role: "UX/UI Designer",
      bio: "Faisal combines artistic talent with user-centered design principles to create intuitive and beautiful interfaces.",
      image: "/placeholder.svg?height=400&width=400",
      social: {
        twitter: "#",
        linkedin: "#",
        github: "#",
        email: "faisal@ksu.edu.sa",
      },
    },
    {
      name: "Noura Al-Salem",
      role: "Data Scientist",
      bio: "Noura specializes in machine learning and data analysis, turning complex data into actionable insights.",
      image: "/placeholder.svg?height=400&width=400",
      social: {
        twitter: "#",
        linkedin: "#",
        github: "#",
        email: "noura@ksu.edu.sa",
      },
    },
    {
      name: "Omar Al-Dossari",
      role: "DevOps Engineer",
      bio: "Omar ensures our infrastructure is robust, scalable, and secure, with expertise in cloud technologies.",
      image: "/placeholder.svg?height=400&width=400",
      social: {
        twitter: "#",
        linkedin: "#",
        github: "#",
        email: "omar@ksu.edu.sa",
      },
    },
    {
      name: "Layan Al-Fawaz",
      role: "Product Manager",
      bio: "Layan bridges the gap between technical implementation and business needs, ensuring our project delivers value.",
      image: "/placeholder.svg?height=400&width=400",
      social: {
        twitter: "#",
        linkedin: "#",
        github: "#",
        email: "layan@ksu.edu.sa",
      },
    },
  ]

  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)]">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-muted/50 to-muted">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Meet Our Team</h1>
              <p className="max-w-[700px] text-muted-foreground md:text-xl">
                The talented individuals behind our innovative project, bringing diverse skills and expertise.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Members */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {teamMembers.map((member, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="aspect-square relative">
                  <Image
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    fill
                    className="object-cover transition-all hover:scale-105"
                  />
                </div>
                <CardHeader>
                  <CardTitle>{member.name}</CardTitle>
                  <CardDescription>{member.role}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{member.bio}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="flex space-x-2">
                    <Link href={member.social.twitter} className="text-muted-foreground hover:text-foreground">
                      <Twitter className="h-5 w-5" />
                      <span className="sr-only">Twitter</span>
                    </Link>
                    <Link href={member.social.linkedin} className="text-muted-foreground hover:text-foreground">
                      <Linkedin className="h-5 w-5" />
                      <span className="sr-only">LinkedIn</span>
                    </Link>
                    <Link href={member.social.github} className="text-muted-foreground hover:text-foreground">
                      <Github className="h-5 w-5" />
                      <span className="sr-only">GitHub</span>
                    </Link>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`mailto:${member.social.email}`}>
                      <Mail className="mr-2 h-4 w-4" />
                      Contact
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Team Values */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4">
              <div className="inline-block rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">
                Our Values
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">What Drives Our Team</h2>
              <p className="text-muted-foreground md:text-xl/relaxed">
                Our team is united by a shared set of values that guide everything we do.
              </p>
              <ul className="space-y-4">
                <li className="flex items-start gap-2">
                  <div className="mt-1 h-2 w-2 rounded-full bg-primary" />
                  <div>
                    <strong>Innovation:</strong> We constantly push boundaries and explore new ideas.
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="mt-1 h-2 w-2 rounded-full bg-primary" />
                  <div>
                    <strong>Collaboration:</strong> We believe the best solutions come from diverse perspectives working
                    together.
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="mt-1 h-2 w-2 rounded-full bg-primary" />
                  <div>
                    <strong>Excellence:</strong> We hold ourselves to the highest standards in everything we do.
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <div className="mt-1 h-2 w-2 rounded-full bg-primary" />
                  <div>
                    <strong>User-Centered:</strong> We put users at the heart of our design and development process.
                  </div>
                </li>
              </ul>
            </div>
            <div className="mx-auto w-full max-w-[500px] lg:max-w-none">
              <Image
                src="/placeholder.svg?height=550&width=550"
                width={550}
                height={550}
                alt="Team Collaboration"
                className="w-full h-auto aspect-square rounded-xl object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Join Our Team */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Join Our Team</h2>
              <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed">
                We're always looking for talented individuals to join our team and help us push the boundaries of
                innovation.
              </p>
            </div>
            <Button asChild size="lg">
              <Link href="/contact">View Open Positions</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
