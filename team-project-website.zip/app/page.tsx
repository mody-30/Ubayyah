import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, CheckCircle, MessageSquare, Search, Lightbulb } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)]">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-ksu-beige">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-ksu-blue">
                Your Smart Assistant for King Saud University
              </h1>
              <p className="max-w-[600px] text-ksu-gray md:text-xl">
                ChatKSU combines AI technology with university knowledge to provide instant answers and assistance to
                students and faculty.
              </p>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button asChild size="lg" className="bg-ksu-blue hover:bg-ksu-blue/90">
                  <Link href="/project">Explore Features</Link>
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  asChild
                  className="border-ksu-blue text-ksu-blue hover:bg-ksu-blue/10"
                >
                  <Link href="/idea-analyzer">Try Idea Analyzer</Link>
                </Button>
              </div>
            </div>
            <div className="mx-auto w-full max-w-[500px] lg:max-w-none">
              <Image
                src="/placeholder.svg?height=550&width=550"
                width={550}
                height={550}
                alt="ChatKSU Assistant"
                className="w-full h-auto aspect-square rounded-xl object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Key Features */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-ksu-blue px-3 py-1 text-sm text-white">Key Features</div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight text-ksu-black">
                What Makes ChatKSU Special
              </h2>
              <p className="max-w-[900px] text-ksu-gray md:text-xl/relaxed">
                ChatKSU combines several innovative technologies to create a seamless and powerful assistant for the
                university community.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3">
            <Card className="bg-white border-ksu-gray/20">
              <CardHeader className="pb-2">
                <MessageSquare className="h-6 w-6 text-ksu-blue" />
                <CardTitle className="mt-2">Instant Answers</CardTitle>
                <CardDescription>Get immediate responses to your university questions</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-ksu-gray">
                  ChatKSU provides instant answers about courses, schedules, policies, and campus services, saving you
                  time and frustration.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-white border-ksu-gray/20">
              <CardHeader className="pb-2">
                <Search className="h-6 w-6 text-ksu-blue" />
                <CardTitle className="mt-2">Smart Search</CardTitle>
                <CardDescription>Find university resources with natural language</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-ksu-gray">
                  Ask questions in your own words and get directed to the exact resources, documents, and information
                  you need.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-white border-ksu-gray/20">
              <CardHeader className="pb-2">
                <Lightbulb className="h-6 w-6 text-ksu-blue" />
                <CardTitle className="mt-2">Idea Analyzer</CardTitle>
                <CardDescription>Get AI-powered analysis for your business ideas</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-ksu-gray">
                  Submit your entrepreneurial ideas and receive comprehensive analysis including market opportunities,
                  implementation plans, and SWOT analysis.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Project Overview */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-ksu-gray/10">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4">
              <div className="inline-block rounded-lg bg-ksu-blue px-3 py-1 text-sm text-white">About ChatKSU</div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight text-ksu-black">
                Enhancing the University Experience
              </h2>
              <p className="text-ksu-gray md:text-xl/relaxed">
                ChatKSU addresses critical challenges faced by students and faculty by providing instant access to
                accurate university information.
              </p>
              <ul className="grid gap-2">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-ksu-blue" />
                  <span>Reduces time spent searching for information by 80%</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-ksu-blue" />
                  <span>Available 24/7 for assistance anytime, anywhere</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-ksu-blue" />
                  <span>Improves student satisfaction with university services</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-ksu-blue" />
                  <span>Provides AI-powered analysis for entrepreneurial ideas</span>
                </li>
              </ul>
              <div className="flex">
                <Button asChild variant="outline" className="gap-1 border-ksu-blue text-ksu-blue hover:bg-ksu-blue/10">
                  <Link href="/project">
                    Learn more about ChatKSU
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
            <div className="mx-auto w-full max-w-[500px] lg:max-w-none">
              <Image
                src="/placeholder.svg?height=550&width=550"
                width={550}
                height={550}
                alt="ChatKSU Overview"
                className="w-full h-auto aspect-square rounded-xl object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight text-ksu-black">
                Ready to Try ChatKSU?
              </h2>
              <p className="max-w-[600px] text-ksu-gray md:text-xl/relaxed">
                Discover how ChatKSU can enhance your university experience and help you succeed at King Saud
                University.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button asChild size="lg" className="bg-ksu-blue hover:bg-ksu-blue/90">
                <Link href="/idea-analyzer">Try Idea Analyzer</Link>
              </Button>
              <Button
                variant="outline"
                size="lg"
                asChild
                className="border-ksu-blue text-ksu-blue hover:bg-ksu-blue/10"
              >
                <Link href="/project">Explore Features</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
