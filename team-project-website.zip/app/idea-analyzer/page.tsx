"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Loader2, Copy } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function IdeaAnalyzerPage() {
  const [idea, setIdea] = useState("")
  const [analysis, setAnalysis] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [copied, setCopied] = useState(false)
  const [charCount, setCharCount] = useState(0)
  const [useMockApi, setUseMockApi] = useState(false)

  const handleIdeaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value
    setIdea(value)
    setCharCount(value.length)
  }

  const analyzeIdea = async () => {
    if (!idea.trim()) {
      setError("الرجاء إدخال فكرة المشروع أولاً")
      return
    }

    setIsLoading(true)
    setError("")
    setAnalysis("")

    try {
      // Choose between real API and mock API
      const apiEndpoint = useMockApi ? "/api/analyze-idea-mock" : "/api/analyze-idea"

      const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ idea }),
      })

      // Check if the response is OK before trying to parse JSON
      if (!response.ok) {
        const errorText = await response.text()
        console.error("API Error Response:", errorText)

        // Try to parse as JSON if possible
        try {
          const errorData = JSON.parse(errorText)
          throw new Error(errorData.error || "حدث خطأ أثناء تحليل الفكرة")
        } catch (jsonError) {
          // If parsing fails, use the raw text
          throw new Error(`حدث خطأ في الخادم: ${errorText.substring(0, 100)}...`)
        }
      }

      const data = await response.json()

      if (!data.result) {
        throw new Error("لم يتم استلام نتيجة التحليل من الخادم")
      }

      setAnalysis(data.result)
    } catch (err) {
      console.error("Error analyzing idea:", err)
      setError(err instanceof Error ? err.message : "❌ حدث خطأ أثناء توليد التحليل")
    } finally {
      setIsLoading(false)
    }
  }

  // Example ideas for testing
  const exampleIdeas = [
    "تطبيق لتوصيل الطعام من المطاعم المحلية",
    "منصة تعليمية للغة العربية للأطفال",
    "خدمة تأجير السيارات الكهربائية",
  ]

  const setExampleIdea = (example: string) => {
    setIdea(example)
    setCharCount(example.length)
    setError("")
    setAnalysis("")
  }

  const copyToClipboard = () => {
    if (!analysis) return

    navigator.clipboard.writeText(analysis).then(
      () => {
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
      },
      (err) => {
        console.error("Could not copy text: ", err)
      },
    )
  }

  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)]">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-ksu-beige">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl text-ksu-blue">
                Oracle Sense – مستشارك الذكي للأفكار الريادية
              </h1>
              <p className="max-w-[700px] text-ksu-gray md:text-xl">
                أدخل فكرة مشروعك وسنقوم بتحليلها فورياً باستخدام الذكاء الاصطناعي
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Idea Analyzer Form */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <Card className="mx-auto max-w-4xl">
            <CardContent className="pt-6">
              <Tabs defaultValue="input" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="input">إدخال الفكرة</TabsTrigger>
                  <TabsTrigger value="settings">إعدادات</TabsTrigger>
                </TabsList>
                <TabsContent value="input" className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label htmlFor="idea" className="text-lg font-medium text-ksu-blue">
                        💡 فكرة مشروعك:
                      </label>
                      <span className="text-sm text-ksu-gray">{charCount} / 500</span>
                    </div>
                    <Textarea
                      id="idea"
                      placeholder="اكتب فكرة مشروعك هنا..."
                      className="min-h-[150px] text-right"
                      dir="rtl"
                      value={idea}
                      onChange={handleIdeaChange}
                      maxLength={500}
                    />
                  </div>

                  {/* Example ideas */}
                  <div className="space-y-2">
                    <p className="text-sm text-ksu-gray">أو جرب أحد الأمثلة:</p>
                    <div className="flex flex-wrap gap-2">
                      {exampleIdeas.map((example, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          onClick={() => setExampleIdea(example)}
                          className="text-right"
                          dir="rtl"
                        >
                          {example}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <Button
                    onClick={analyzeIdea}
                    className="w-full bg-ksu-blue hover:bg-ksu-blue/90"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        جاري التحليل...
                      </>
                    ) : (
                      "🔍 حلل الفكرة"
                    )}
                  </Button>
                </TabsContent>
                <TabsContent value="settings">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="useMockApi"
                        checked={useMockApi}
                        onChange={(e) => setUseMockApi(e.target.checked)}
                        className="h-4 w-4"
                      />
                      <label htmlFor="useMockApi" className="text-sm font-medium">
                        استخدام واجهة API التجريبية (للاختبار فقط)
                      </label>
                    </div>
                    <p className="text-sm text-ksu-gray">
                      استخدم هذا الخيار إذا كنت تواجه مشاكل مع واجهة API الحقيقية. سيتم استخدام بيانات تجريبية بدلاً من
                      الاتصال بـ OpenAI.
                    </p>
                  </div>
                </TabsContent>
              </Tabs>

              {error && (
                <Alert variant="destructive" className="mt-6">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {analysis && (
                <div className="mt-8 space-y-4">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold text-ksu-blue">التحليل الذكي بواسطة الذكاء الاصطناعي:</h2>
                    <Button variant="outline" size="sm" onClick={copyToClipboard}>
                      <Copy className="h-4 w-4 mr-2" />
                      {copied ? "تم النسخ!" : "نسخ النتائج"}
                    </Button>
                  </div>
                  <div
                    className="prose prose-blue max-w-none text-right border rounded-md p-4"
                    dir="rtl"
                    dangerouslySetInnerHTML={{
                      __html: analysis.replace(/\n/g, "<br />"),
                    }}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
