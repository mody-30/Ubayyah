import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, Clock, Code, Cpu, Database, Layers, Lock, Zap } from "lucide-react"

export default function FeaturesPage() {
  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)]">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-ksu-beige">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl text-ksu-blue">ChatKSU Features</h1>
              <p className="max-w-[600px] text-ksu-gray md:text-xl">
                An in-depth look at how ChatKSU is enhancing the university experience at King Saud University.
              </p>
            </div>
            <div className="mx-auto w-full max-w-[500px] lg:max-w-none">
              <Image
                src="/placeholder.svg?height=400&width=700"
                width={700}
                height={400}
                alt="ChatKSU Details"
                className="w-full h-auto aspect-video rounded-xl object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* ChatKSU Overview */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-3xl space-y-8">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-ksu-blue">ChatKSU Overview</h2>
              <p className="text-ksu-gray">
                Our ChatKSU is the result of years of research and development, aimed at solving critical challenges in
                the university.
              </p>
            </div>
            <div className="space-y-4">
              <p className="text-ksu-gray">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et
                dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                ex ea commodo consequat.
              </p>
              <p className="text-ksu-gray">
                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
                laborum.
              </p>
            </div>
            <Image
              src="/placeholder.svg?height=400&width=800"
              width={800}
              height={400}
              alt="ChatKSU Diagram"
              className="w-full h-auto rounded-xl object-cover"
            />
          </div>
        </div>
      </section>

      {/* Technical Details */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-ksu-beige">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-3xl space-y-8">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-ksu-blue">Technical Details</h2>
              <p className="text-ksu-gray">
                A closer look at the technology stack and architecture behind our ChatKSU.
              </p>
            </div>

            <Tabs defaultValue="architecture" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="architecture" className="text-ksu-blue">
                  Architecture
                </TabsTrigger>
                <TabsTrigger value="stack" className="text-ksu-blue">
                  Tech Stack
                </TabsTrigger>
                <TabsTrigger value="security" className="text-ksu-blue">
                  Security
                </TabsTrigger>
              </TabsList>
              <TabsContent value="architecture" className="space-y-4 pt-4">
                <div className="flex items-center gap-4">
                  <Layers className="h-10 w-10 text-ksu-blue" />
                  <div>
                    <h3 className="text-xl font-bold text-ksu-blue">Microservices Architecture</h3>
                    <p className="text-ksu-gray">
                      Our ChatKSU is built on a modern microservices architecture for maximum scalability and
                      resilience.
                    </p>
                  </div>
                </div>
                <Image
                  src="/placeholder.svg?height=300&width=700"
                  width={700}
                  height={300}
                  alt="Architecture Diagram"
                  className="w-full h-auto rounded-xl object-cover"
                />
                <p className="text-ksu-gray">
                  The architecture consists of several independent services that communicate through APIs, allowing for
                  independent scaling and deployment of each component.
                </p>
              </TabsContent>
              <TabsContent value="stack" className="space-y-4 pt-4">
                <div className="flex items-center gap-4">
                  <Code className="h-10 w-10 text-ksu-blue" />
                  <div>
                    <h3 className="text-xl font-bold text-ksu-blue">Modern Technology Stack</h3>
                    <p className="text-ksu-gray">
                      We use cutting-edge technologies to ensure performance, reliability, and developer productivity.
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-ksu-blue">Frontend</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-ksu-gray">React, Next.js, TypeScript</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-ksu-blue">Backend</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-ksu-gray">Node.js, Express, Python</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-ksu-blue">Database</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-ksu-gray">PostgreSQL, MongoDB, Redis</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-ksu-blue">Infrastructure</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-ksu-gray">Docker, Kubernetes, AWS</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-ksu-blue">AI/ML</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-ksu-gray">TensorFlow, PyTorch, Scikit-learn</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-ksu-blue">DevOps</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-ksu-gray">GitHub Actions, Jenkins, Terraform</p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="security" className="space-y-4 pt-4">
                <div className="flex items-center gap-4">
                  <Lock className="h-10 w-10 text-ksu-blue" />
                  <div>
                    <h3 className="text-xl font-bold text-ksu-blue">Security First Approach</h3>
                    <p className="text-ksu-gray">
                      Security is built into every layer of our application, from code to infrastructure.
                    </p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <div className="mt-1 h-2 w-2 rounded-full bg-ksu-blue" />
                    <p className="text-ksu-gray">End-to-end encryption for all data in transit and at rest</p>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="mt-1 h-2 w-2 rounded-full bg-ksu-blue" />
                    <p className="text-ksu-gray">Regular security audits and penetration testing</p>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="mt-1 h-2 w-2 rounded-full bg-ksu-blue" />
                    <p className="text-ksu-gray">Multi-factor authentication for all access points</p>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="mt-1 h-2 w-2 rounded-full bg-ksu-blue" />
                    <p className="text-ksu-gray">Compliance with industry standards (GDPR, HIPAA, SOC2)</p>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="mt-1 h-2 w-2 rounded-full bg-ksu-blue" />
                    <p className="text-ksu-gray">Automated vulnerability scanning in CI/CD pipeline</p>
                  </li>
                </ul>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* Key Features */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-3xl space-y-8">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-ksu-blue">Key Features</h2>
              <p className="text-ksu-gray">
                Discover the powerful features that make our ChatKSU stand out from the competition.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader className="pb-2">
                  <Zap className="h-6 w-6 text-ksu-blue" />
                  <CardTitle className="mt-2 text-ksu-blue">High Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-ksu-gray">
                    Optimized for speed and efficiency, our solution processes data 10x faster than traditional
                    approaches.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <Cpu className="h-6 w-6 text-ksu-blue" />
                  <CardTitle className="mt-2 text-ksu-blue">AI-Powered Insights</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-ksu-gray">
                    Advanced machine learning algorithms provide intelligent insights and recommendations.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <Database className="h-6 w-6 text-ksu-blue" />
                  <CardTitle className="mt-2 text-ksu-blue">Scalable Infrastructure</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-ksu-gray">
                    Built to scale seamlessly from startups to enterprise-level operations without performance
                    degradation.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <BarChart className="h-6 w-6 text-ksu-blue" />
                  <CardTitle className="mt-2 text-ksu-blue">Advanced Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-ksu-gray">
                    Comprehensive analytics dashboard with real-time metrics and customizable reports.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <Clock className="h-6 w-6 text-ksu-blue" />
                  <CardTitle className="mt-2 text-ksu-blue">Automation</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-ksu-gray">
                    Automate repetitive tasks and workflows to save time and reduce human error.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <Lock className="h-6 w-6 text-ksu-blue" />
                  <CardTitle className="mt-2 text-ksu-blue">Enterprise-Grade Security</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-ksu-gray">
                    Robust security measures to protect sensitive data and ensure compliance with regulations.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-ksu-beige">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight text-ksu-blue">
                Ready to Transform Your University Experience?
              </h2>
              <p className="max-w-[600px] text-ksu-gray md:text-xl/relaxed">
                Contact our team to learn how our ChatKSU can help you achieve your goals.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button asChild size="lg">
                <Link href="/contact">Get in Touch</Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/team">Meet Our Team</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
