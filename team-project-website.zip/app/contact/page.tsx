"use client"
import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export default function FAQPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const faqs = [
    {
      question: "What is ChatKSU?",
      answer:
        "ChatKSU is an AI-powered smart assistant designed specifically for King Saud University students and faculty. It provides instant answers to questions about courses, schedules, university policies, campus services, and more.",
    },
    {
      question: "How do I access ChatKSU?",
      answer:
        "ChatKSU is available through the university portal, mobile app, and as a standalone web application. You can log in using your KSU credentials.",
    },
    {
      question: "Is ChatKSU available 24/7?",
      answer: "Yes, ChatKSU is available 24 hours a day, 7 days a week to assist you with your questions and needs.",
    },
    {
      question: "What kind of questions can ChatKSU answer?",
      answer:
        "ChatKSU can answer questions about course schedules, registration procedures, campus facilities, academic policies, events, faculty information, and much more. It's designed to handle a wide range of university-related inquiries.",
    },
    {
      question: "Is my conversation with ChatKSU private?",
      answer:
        "Yes, your conversations with ChatKSU are private and secure. We follow strict data protection protocols to ensure your information remains confidential.",
    },
    {
      question: "Can ChatKSU help with my research?",
      answer:
        "ChatKSU can provide general guidance on research resources available at KSU, direct you to relevant databases, and help you find faculty experts in your field of interest.",
    },
    {
      question: "What languages does ChatKSU support?",
      answer: "Currently, ChatKSU supports both Arabic and English to serve the diverse KSU community.",
    },
    {
      question: "How accurate is the information provided by ChatKSU?",
      answer:
        "ChatKSU is trained on official KSU documentation and is regularly updated to ensure accuracy. However, for critical matters, we recommend verifying information through official university channels.",
    },
  ]

  const filteredFaqs = faqs.filter(
    (faq) =>
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)]">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-ksu-beige">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl text-ksu-blue">
                Frequently Asked Questions
              </h1>
              <p className="max-w-[700px] text-ksu-gray md:text-xl">
                Find answers to common questions about ChatKSU and how it can help you at King Saud University.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form and Info */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-1 lg:gap-12">
            <Card>
              <CardContent>
                <div className="flex items-center mb-4">
                  <Search className="mr-2 h-5 w-5 text-gray-500" />
                  <Input
                    type="text"
                    placeholder="Search FAQs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-1"
                  />
                </div>
                <Accordion type="single" collapsible>
                  {filteredFaqs.map((faq, index) => (
                    <AccordionItem value={`${index}`} key={index}>
                      <AccordionTrigger>{faq.question}</AccordionTrigger>
                      <AccordionContent>{faq.answer}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Map Section */}
      {/*<section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-3xl space-y-4">
            <h2 className="text-2xl font-bold tracking-tighter text-center">Find Us</h2>
            <div className="aspect-video overflow-hidden rounded-xl border bg-muted">
              {/* This would be replaced with an actual map component in a real project */}
      {/*<div className="flex h-full items-center justify-center bg-muted p-8 text-center">
                <p className="text-muted-foreground">Interactive map would be displayed here</p>
              </div>
            </div>
          </div>
        </div>
              </section>*/}
    </div>
  )
}
