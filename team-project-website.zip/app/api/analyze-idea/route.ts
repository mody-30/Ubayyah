import { NextResponse } from "next/server"
import { Configuration, OpenAIApi } from "openai"

// Initialize OpenAI client using the older, more stable method
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
})
const openai = new OpenAIApi(configuration)

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()
    const { idea } = body

    if (!idea || idea.trim() === "") {
      return NextResponse.json({ error: "الرجاء إدخال فكرة المشروع" }, { status: 400 })
    }

    // Check if API key is available
    if (!process.env.OPENAI_API_KEY) {
      console.error("Missing OpenAI API key")
      return NextResponse.json({ error: "OpenAI API key is not configured" }, { status: 500 })
    }

    // Create the prompt for GPT
    const prompt = `
أنت مستشار ذكي لتحليل الأفكار الريادية. قم بتحليل فكرة المشروع التالية: "${idea}"، وقدم التقرير بالتنسيق التالي دائمًا بدون تغيير:

1. **وصف المشروع:**  
وصف واضح للفكرة وأهميتها.

2. **خطة التنفيذ (3 خطوات):**  
- خطوة 1  
- خطوة 2  
- خطوة 3

3. **فرص السوق:**  
اذكر أرقام أو اتجاهات أو فرص في السوق السعودي أو الخليجي.

4. **التحديات:**  
ما الصعوبات المتوقعة؟ وكيف يمكن تجاوزها؟

5. **الجمهور المستهدف:**  
من هم العملاء؟ أعمارهم؟ عاداتهم؟ كيف نصل لهم؟

6. **الخطة التسويقية (بداية المشروع):**  
اقتراح طرق تسويق فعالة لمدة أول 3 أشهر.

7. المنافسين (يرجى عرضهم في جدول منسق مع وضع منافسين حقيقين اسماء وان لم يوجد نكتفي ب الاحرف ):

| الاسم | نقطة القوة | نقطة الضعف | نوع الخدمة |
|------|-------------|-------------|-------------|
|      |             |             |             |
|      |             |             |             |
|      |             |             |             |

8. **تحليل SWOT:**  
- نقاط القوة:  
- نقاط الضعف:  
- الفرص:  
- التهديدات:  

9. **توصيات نهائية:**  
نصائح مختصرة تعزز نجاح المشروع.
10.اضف شكل احصائي عن المشروع 

**التزم بهذا التنسيق بالحرف، ولا تخلط أو تحذف أي قسم حتى لو كانت الفكرة بسيطة.**
`

    try {
      // Call OpenAI API using the older method
      const completion = await openai.createChatCompletion({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 1000,
        temperature: 0.2,
      })

      // Add defensive checks for the response structure
      if (!completion.data) {
        console.error("OpenAI API returned no data")
        return NextResponse.json({ error: "No data received from OpenAI API" }, { status: 500 })
      }

      if (!completion.data.choices || completion.data.choices.length === 0) {
        console.error("OpenAI API returned no choices", completion.data)
        return NextResponse.json({ error: "No choices received from OpenAI API" }, { status: 500 })
      }

      const choice = completion.data.choices[0]
      if (!choice.message || !choice.message.content) {
        console.error("OpenAI API returned no message content", choice)
        return NextResponse.json({ error: "No message content received from OpenAI API" }, { status: 500 })
      }

      // Extract the response content
      const analysisResult = choice.message.content

      return NextResponse.json({ result: analysisResult })
    } catch (error: any) {
      console.error("OpenAI API Error:", error)

      // Check for specific error types
      if (error.response) {
        console.error("OpenAI API Response Error:", error.response.status, error.response.data)
        return NextResponse.json(
          {
            error: "❌ حدث خطأ أثناء توليد التحليل",
            details: `API Error: ${error.response.status} - ${JSON.stringify(error.response.data)}`,
          },
          { status: error.response.status || 500 },
        )
      }

      // Return a properly formatted JSON response with error details
      return NextResponse.json(
        {
          error: "❌ حدث خطأ أثناء توليد التحليل",
          details: error.message || "Unknown OpenAI error",
        },
        { status: 500 },
      )
    }
  } catch (error: any) {
    console.error("Request Processing Error:", error)

    // Return a properly formatted JSON response for any other errors
    return NextResponse.json(
      {
        error: "حدث خطأ أثناء معالجة الطلب",
        details: error.message || "Unknown error",
      },
      { status: 500 },
    )
  }
}
