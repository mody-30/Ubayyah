"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"

export default function Header() {
  const pathname = usePathname()

  const navigation = [
    { name: "Home", href: "/" },
    { name: "Features", href: "/project" },
    { name: "Team", href: "/team" },
    { name: "Idea Analyzer", href: "/idea-analyzer" },
    { name: "FAQ", href: "/contact" },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-ksu-beige text-ksu-black">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="font-bold text-xl text-ksu-blue">
            ChatKSU
          </Link>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          {navigation.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`text-sm font-medium transition-colors hover:text-ksu-blue ${
                pathname === item.href ? "text-ksu-blue" : "text-ksu-gray"
              }`}
            >
              {item.name}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  )
}
