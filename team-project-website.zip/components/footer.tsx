import Link from "next/link"

export default function Footer() {
  return (
    <footer className="border-t bg-ksu-beige text-ksu-black">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-3">
            <h3 className="text-lg font-medium text-ksu-blue">ChatKSU</h3>
            <p className="text-sm text-ksu-gray">Smart Assistant for King Saud University students and faculty.</p>
          </div>
          <div className="space-y-3">
            <h3 className="text-sm font-medium">Pages</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-sm text-ksu-gray hover:text-ksu-blue">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/project" className="text-sm text-ksu-gray hover:text-ksu-blue">
                  Features
                </Link>
              </li>
              <li>
                <Link href="/team" className="text-sm text-ksu-gray hover:text-ksu-blue">
                  Team
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-sm text-ksu-gray hover:text-ksu-blue">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-3">
            <h3 className="text-sm font-medium">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-sm text-ksu-gray hover:text-ksu-blue">
                  User Guide
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-ksu-gray hover:text-ksu-blue">
                  API Documentation
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-ksu-gray hover:text-ksu-blue">
                  Blog
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-3">
            <h3 className="text-sm font-medium">University</h3>
            <ul className="space-y-2">
              <li className="text-sm text-ksu-gray">support@chatksu.edu.sa</li>
              <li className="text-sm text-ksu-gray">King Saud University, Riyadh, Saudi Arabia</li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-ksu-gray/20 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-xs text-ksu-gray">
            © {new Date().getFullYear()} King Saud University. All rights reserved.
          </p>
          <div className="flex gap-4 mt-4 md:mt-0">
            <Link href="#" className="text-ksu-gray hover:text-ksu-blue">
              Privacy
            </Link>
            <Link href="#" className="text-ksu-gray hover:text-ksu-blue">
              Terms
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
